Zadaci sa domaceg zadatka 2 su objedinjeni tako da
je prvi zadatak implementiran u okviru stranice "index.html",
dok je drugi zadatak implementiran u okviru stranice "pages/pricing.html"
